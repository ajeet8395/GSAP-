/******************************************** USING GSAP AND JS CODE ***********************************/
gsap.set('.cursor',{xPercent:-50,yPercent:-50});  // Set the initial position of the cursor element using GSAP.

var dot = document.querySelector('.cursor'); // Select the cursor element from the DOM.

// Function to generate a random color
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

window.addEventListener('mousemove', e => {  // Add an event listener to track mouse movement.
    gsap.to(dot,0.2,{x:e.clientX,y:e.clientY});      // Use GSAP to attach the cursor element to the current mouse position.
});

var currentScale = 1;

// Create New Feature when mouse press than my cursor size will inc. & dec.
window.addEventListener('mousedown', e =>{   // When mouse button press
    currentScale += 2
    gsap.to(dot, {scale: currentScale});
    gsap.to(dot, { backgroundColor: getRandomColor(), duration: 0.2 }); // Change the background color randomly.
});


window.addEventListener('mouseup', e=>{  
    currentScale -= 1.8;     // When mouse button unpress
     gsap.to(dot, { scale: currentScale });
});




// /********************************************** USING PURE JS CODE ***************************************/
// // document.addEventListener('DOMContentLoaded', function () {
// //     var cursor = document.querySelector('.cursor');      // Select the cursor element from the DOM.

// //     cursor.style.transform = 'translate(-50%, -50%)';    // Set the initial position and transition properties
// //     cursor.style.transition = 'transform 0.1s ease';     // Give animation and smoothness to cursor

// //     document.addEventListener('mousemove', function (e) {      // Add an event listener to track mouse movement.
// //         cursor.style.transform = 'translate(' + e.clientX + 'px, ' + e.clientY + 'px)';          // Set the cursor position based on the mouse coordinates.
// //     });
// // });




// /********************************************** CODE FOR IMAGE SCROLLER ***************************************/
// let frameCount = 147,
//     urls = new Array(frameCount).fill().map((o, i) => `https://www.apple.com/105/media/us/airpods-pro/2019/1299e2f5_9206_4470_b28e_08307a42f19b/anim/sequence/large/01-hero-lightpass/${(i+1).toString().padStart(4, '0')}.jpg`);

// imageSequence({
//   urls,
//   canvas: "#image-sequence",
//   scrollTrigger: {
//     start: 0,   
//     end: "max", 
//     scrub: true, 
//   }
// });



// function imageSequence(config) {
//   let playhead = {frame: 0},
//       canvas = gsap.utils.toArray(config.canvas)[0] || console.warn("canvas not defined"),
//       ctx = canvas.getContext("2d"),
//       curFrame = -1,
//       onUpdate = config.onUpdate,
//       images,
//       updateImage = function() {
//         let frame = Math.round(playhead.frame);
//         if (frame !== curFrame) {
//           config.clear && ctx.clearRect(0, 0, canvas.width, canvas.height);
//           ctx.drawImage(images[Math.round(playhead.frame)], 0, 0);
//           curFrame = frame;
//           onUpdate && onUpdate.call(this, frame, images[frame]);
//         }
//       };
//   images = config.urls.map((url, i) => {
//     let img = new Image();
//     img.src = url;
//     i || (img.onload = updateImage);
//     return img;
//   });
//   return gsap.to(playhead, {
//     frame: images.length - 1,
//     ease: "none",
//     onUpdate: updateImage,
//     duration: images.length / (config.fps || 30),
//     paused: !!config.paused,
//     scrollTrigger: config.scrollTrigger
//   });
// }