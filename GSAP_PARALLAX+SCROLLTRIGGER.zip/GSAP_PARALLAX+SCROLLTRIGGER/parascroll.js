//Cursor Animation
gsap.set('.cursor',{xPercent:-50,yPercent:-50});  

var dot = document.querySelector('.cursor'); 

window.addEventListener('mousemove', e => {  
    gsap.to(dot,0.5,{x:e.clientX,y:e.clientY});      
});





// Animation of moving images with scroll
gsap.to("#bg", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  scale: 1.5,
});

gsap.to("#man", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  scale: .5,
});

gsap.to("#mountain_left", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  x: -600,
});

gsap.to("#mountain_right", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  x: 600,
});

gsap.to("#text-1", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  y: 500,
});

gsap.to("#clouds_1", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1,
  },
  x: 300,
});

gsap.to("#clouds_2", {
  scrollTrigger: {
    trigger: ".sec",
    scrub: 1
  },
  x: -300,
});







/******** ALPHABET ANIMATION ******/
// Function to create animation timeline for a specific quote
function createQuoteAnimation(quoteId) {
  var tl = gsap.timeline(),
    mySplitText = new SplitText(quoteId, { type: "chars" }),
    chars = mySplitText.chars;

  tl.from(chars, {
    duration: 1,
    opacity: 0,
    scale: 0,
    y: 150,
    rotationX: 240,
    transformOrigin: "0% 50% -50%",
    ease: "back",
    stagger: 0.21
  });

  ScrollTrigger.create({
    trigger: quoteId,
    start: "top 80%",
    onEnter: function () {
      tl.restart();
    },
  });
}

createQuoteAnimation("#quote_1");
createQuoteAnimation("#quote_11");




/******* WORD ANIMATION *******/
var tl2 = gsap.timeline(),
  mySplitText = new SplitText("#quote_2", { type: "words" }),
  words = mySplitText.words;

tl2.from(words, {
  duration: 1,
  opacity: 1,
  scale: 0,
  y: 150,
  rotationX: 180,
  transformOrigin: "-50% -50% 0",
  ease: "back",
  stagger: 0.03
});

ScrollTrigger.create({
  trigger: "#quote_2",
  start: "top 80%",
  onEnter: function () {
    tl2.restart();
  },
  once: true,
});


// text change animation
var text1 = document.querySelector('#text-1');
var tl3 = gsap.timeline({ paused: true });
var textLoad1 = () => {
  tl3.to(text1, { duration: 0, textContent: "Welcome", ease: "back"});

}

ScrollTrigger.create({
  trigger: ".thirdp",
  onEnter: function () {
    textLoad1();
    tl3.restart();
  },
  onLeaveBack: function () {
    tl3.reverse();
  }
})



// infinite scrolling text
const rows = document.querySelectorAll(".it-tagreel-row");

rows.forEach(function (e, i) {
  let row_width = e.getBoundingClientRect().width;
  let row_item_width = e.children[0].getBoundingClientRect().width;
  let initial_offset = ((2 * row_item_width) / row_width);
  
  gsap.set(e, {
    xPercent: `${initial_offset}`
  });

  let duration = 2 * (i + 1);

  var tl4 = gsap.timeline();

  tl4.to(e, {
    ease: "none",
    duration: duration,
    xPercent: -100 + initial_offset * 100,
    repeat: -1,
    yoyo: true
  });
});




// for moving right to left
// let initial_offset = ((2 * row_item_width) / row_width) * 100;
// let x_translation = initial_offset;


// parallax
const parallax = document.getElementById("parallax");

window.addEventListener("scroll", function () {
  let offset = window.pageYOffset;
  parallax.style.backgroundPositionY = offset * 0.7 + "px";
  // DIV 1 background will move slower than other elements on scroll.
});

